#include "compare.h"

/*function to search for the matching value using in-order traversal tree*/
void inOrderTravesal(char* key, FILE *nf, struct node* leaf, Compare cmp, int* count,int* countTime);