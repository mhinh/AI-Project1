typedef int (*Compare)(const char *, const char *);

/*a function to compare two strings */
int CmpStr(const char *a, const char *b);