/*function to get the value in each comma */
/*contributed to the answer in this website
"https://stackoverflow.com/questions/12911299/read-csv-file-in-c"*/
const char* getvalue(char* line, int num);