#include "compare.h"

/*function to search for the searching keys and print the 
number of comparisons*/
void search(char* key,FILE* nf, struct node* leaf, Compare cmp,int* count);